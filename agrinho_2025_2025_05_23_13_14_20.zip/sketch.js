function setup() {
  createCanvas(600, 400);
  noLoop();
}

function draw() {
  
  background(135, 206, 235);
  
  
  fill(34, 139, 34);
  rect(0, height/2, width, height/2);
  
  
  fill(255, 255, 0);
  for (let i = 0; i < 20; i++) {
    let x = random(width);
    let y = random(height/2, height);
    ellipse(x, y, 10, 10);
  }
  
  
  fill(255, 223, 0);
  ellipse(80, 80, 50, 50);
}